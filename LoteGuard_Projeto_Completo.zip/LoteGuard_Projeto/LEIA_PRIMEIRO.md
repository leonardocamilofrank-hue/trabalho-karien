# LoteGuard — Operação Lote Crítico

Projeto acadêmico da SuperRede baseado no PDF **Avaliação Prática Integradora — Operação Lote Crítico** (7 páginas). Inclui documentação técnica, diagramas, matriz, identidade visual e protótipo navegável.

## Entregas e locais

1. **Diagrama UML de casos de uso:** `diagramas/casos_de_uso.png`, `casos_de_uso_svg.svg` e `casos_de_uso.dot` (fonte Graphviz).
2. **Especificações textuais de dez casos de uso:** `documentacao/Projeto_LoteGuard_Dossie.pdf` (seção 6); casos com principal, alternativos, exceções, pré/pós-condições.
3. **Diagrama UML de classes:** `diagramas/classes_uml.png`, `classes_uml_svg.svg`, `classes_uml.dot`. Inclui classes, métodos, atributos tipados, relacionamentos e multiplicidades.
4. **Identidade visual:** `prototipo/assets/logo.svg`, `mark.svg`, `mapa_fluxo.svg`, `estado_vazio.svg`; paleta e tipografia descritas no PDF, recursos aplicados na interface.
5. **Protótipo navegável:** `prototipo/index.html` com `style.css` e `app.js`; inclui 17 telas/estados de interface, diálogos, busca sem resultado, perfis, bloqueio, ajuste, auditoria e operações recusadas.
6. **Matriz RN01–RN12:** `documentacao/matriz_rastreabilidade.xlsx` e seção 10 do PDF.
7. **Apresentação:** `apresentacao/Defesa_LoteGuard.pptx`, 16 slides.

## Como abrir o protótipo

**Modo rápido:** descompacte o pacote inteiro e abra `prototipo/index.html` no Chrome, Edge ou Firefox. Navegue selecionando pessoas demonstrativas no login.

**Se o navegador restringir arquivos locais**, execute um servidor estático na pasta `prototipo`:

No Windows, abra o Terminal dentro da pasta e execute:

```powershell
py -m http.server 8000
```

Depois abra `http://localhost:8000/`. Não é necessário instalar pacotes JavaScript; só o Python caso escolha o servidor.

**Link público:** o pacote não cria uma URL pública por conta própria. Para entregar um endereço acessível ao professor, publique o conteúdo da pasta `prototipo` no GitHub Pages, Netlify ou serviço de hospedagem estática equivalente. Depois confira se todos os arquivos SVG/CSS/JS estão no mesmo diretório relativo antes de enviar o link.

## Pessoas e perfis de demonstração

- **Carlos Lima — Operador de recebimento**: conferir, cadastrar lotes e movimentar estoque autorizado.
- **Marina Souza — Inspetora de qualidade**: inspecionar, aprovar/reprovar, liberar, aplicar bloqueio técnico e reinspecionar.
- **Ana Costa — Gerente da loja**: solicita bloqueio, ajusta estoque, autoriza desbloqueio e exceção.
- **Paulo Silva — Gerente da loja**: autoriza ajuste que Ana solicitou (pessoas diferentes).
- **Beatriz Mendes — Gestora de compras**: consulta pedidos e ocorrências de fornecedores.
- **Ricardo Rocha — Auditor**: consulta rastreabilidade, estoque e auditoria; não altera esses dados.
- **Sofia Almeida — Administradora do sistema**: cria/desativa usuários e modifica perfis; não libera mercadorias nem edita a auditoria.

**Importante:** clique em **“Sair”** para trocar de pessoa. O botão **“Reiniciar cenários”** limpa as operações do navegador e restabelece os dados de teste.

## Demonstração recomendada (A até E)

- **A — Divergência (RN02, RN03):** Carlos abre Pedidos → Conferência de entrega. Pedido 500, entrega 460, sendo 40 críticos. A conferência cria dois sublotes: 420 conformes e 40 excepcionais. Os 40 faltantes ficam em ocorrência. A quantidade pedida original continua 500. Marina pode registrar inspeção. Um lote crítico tecnicamente aprovado ainda exige **autorização excepcional da gerente** e **liberação explícita da inspetora**.
- **B — Bloqueio global (RN05):** Ana abre Bloqueio / desbloqueio → LT-2026-240 → “Solicitar bloqueio preventivo”. As lojas 01/02/03 continuam com 80/100/60 registrados, mas ficam com disponível zero. Veja também Estoque e tente movimentar.
- **C — Desbloqueio indevido (RN06):** Ana seleciona LT-2026-078, definitivamente reprovado, e tenta desbloquear. A tentativa é recusada e registrada.
- **D — Ajuste (RN08):** Ana abre Ajustes, pede 120 → 93 com justificativa. Ela mesma tenta aprovar: sistema nega. Sai, entra Paulo, e autoriza. Veja o histórico de valores e responsáveis.
- **E — Auditoria (RN09, RN10):** Ricardo consulta LT-2026-240 em Rastrear lote e depois filtra o código no Histórico de auditoria. Verá eventos, transições e autores, sem opções de editar/apagar.

**Testes extras:** Carlos tenta registrar código duplicado `LT-2026-240` e movimentar quantidade 999; Ricardo tenta acessar Ajustes; filtros sem resultado revelam uma mensagem de consulta vazia. Sofia pode cadastrar um usuário no fluxo administrativo.

## Decisões complementares e limites

- Identificador de lote é único no âmbito da empresa. Sublotes de validade diferente recebem identificadores distintos.
- A **quarentena preventiva** após alerta de risco alcança simultaneamente todas as unidades do lote. Parecer favorável de reinspeção não libera automaticamente: exige autorização de gerente.
- **Estoque disponível** não coincide com estoque físico ou registrado. Lotes em qualquer estado diferente de LIBERADO têm disponível zero.
- A simulação mantém dados em `localStorage`. Não tem backend, banco transacional, autenticação real ou trilha de auditoria imutável em servidor. Não é adequada a operação real de supermercado. A interface implementa as verificações para demonstrar o projeto acadêmico, e a arquitetura de produção precisaria repetir o RBAC no backend.
- O estado ENCERRADO foi modelado no diagrama de classes/estados e documentado; o descarte final não é um fluxo interativo separado. Os doze fluxos de tela expressamente exigidos pelo PDF estão presentes.
- O material usa dados de fornecedores, pessoas e lotes **fictícios**. Leiam os casos de uso e o roteiro de defesa antes da apresentação individual.

## Verificação técnica realizada

A simulação foi exercitada com navegador automatizado: conferência divergente, recusa de saída acima do saldo, bloqueio simultâneo de três lojas, recusa de desbloqueio definitivo, impedimento de autoaprovação, autorização por outro gerente, acesso negado ao auditor e criação de usuário pelo administrador. Não foram detectados erros de JavaScript nesses testes. O PDF e os recursos gráficos foram exportados e inspecionados. Isso não substitui validação manual de todos os caminhos pelo grupo.
